package indicatorrelationstransformator;
import java.*;
import java.util.List;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class FileReader {
	private List<Indicator> indicators;
	private FileInputStream fileStream = null;
	private BufferedReader reader = null ;
	private String buffer;
	private int LINES_TO_IGNORE = 3;
	private int indicatorId = 0; 
	
	private void initialize(){
		indicators = new ArrayList<Indicator>();
		openFile();
	}
	
	private void openFile(){
		try {
			fileStream = new FileInputStream("/home/nikospaxos/Desktop/king/data.csv");
			reader = new BufferedReader(new InputStreamReader(fileStream));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}		
	}
	
	private boolean isAllIndicatorsRead(String startCountry,String currentCountry){
		return !startCountry.equals(currentCountry);		
	}
	
	private void readLine() throws Exception{
		buffer = reader.readLine();
	}
	
	private String[] loadNewIndicator() throws Exception{
		readLine();
		return buffer.split("\"");
	}
	
	private void addNewIndicator(String[] split){
		indicators.add(new Indicator(indicatorId++,split[5],split[7]));	
	}
	
	private void proccessFile() throws Exception{
		String countryName =" ", currentCountryName= " ";
		String split[];
		ignoreLines(LINES_TO_IGNORE);

		split = loadNewIndicator();
		currentCountryName = countryName = split[1];
		addNewIndicator(split);
		while ( true ){
			split = loadNewIndicator();
			currentCountryName = split[1];
			if ( isAllIndicatorsRead(countryName, currentCountryName))
				break;
			addNewIndicator(split);
		}
	}
	
	private void closeFile() throws Exception{
		fileStream.close();
		reader.close();
	}
	
	public List<Indicator> readFile(){
		try {
			initialize();
			proccessFile();
			closeFile();
		} catch (Exception e) {
			e.printStackTrace();
		}		
		return indicators;
	}
	
	private void ignoreLines(int linesToIgnore) throws Exception{
		for(int i=0; i<linesToIgnore; i++)
			buffer = reader.readLine();
	}
}
