package indicatorrelationstransformator;
import java.util.List;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;


public class IndicatorsTransformation {
	public static List<Indicator> main(String []args){
		FileReader parser = new FileReader();
		List<Indicator> indicators = parser.readFile();
		OutputWriter output = new OutputWriter(indicators);
		return indicators;
	}
}
