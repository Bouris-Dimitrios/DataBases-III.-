package indicatorrelationstransformator;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.List;
public class OutputWriter {
	private PrintWriter writer;
	private final String fileName = "IndicatorsRelation.txt";
	private List <Indicator>indicators;
	
	public OutputWriter(List<Indicator> indicators){
		try {	
			this.indicators = indicators;
			openFile();
			writeIndicatorsRelation();
			closeFile();
		} catch (Exception exceptionHandler) {
			System.out.println("Exception : " + exceptionHandler.getMessage());
		}
	}

	private void writeIndicatorsRelation(){
		for(Indicator iter : indicators)
			writer.println(iter.getStringWithAllData());
	}
	
	private void  openFile()throws IOException{
		try {
			writer = new PrintWriter(fileName, "UTF-8");
		} catch (Exception exceptionHandler) {
			System.out.println("Exception : " + exceptionHandler.getMessage());
		}
	}
	
	private void closeFile() throws IOException{
		writer.close();
	}
}
