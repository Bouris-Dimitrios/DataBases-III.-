package indicatorrelationstransformator;

public class Indicator {
	private int id;
	private String name;
	private String code;
	
	public Indicator(int id, String name, String code){
		this.id = id;
		this.name = name;
		this.code = code;
	}
	
	public void print(){
		System.out.println("[" + id + "]: " + name + " , " + code);
	}
	
	public String getStringWithAllData(){
		return id + "@" + name + "@" + code;
	}
	
	public String getName(){
		return name;
	}
	
	public String getCode(){
		return code;
	}
	
	public int getId(){
		return id;
	}
}

