package countriesrelationtransofrmator;
import java.util.Comparator;


public class CustomComparator implements Comparator<EUCountry>{
	   public int compare(EUCountry country1, EUCountry country2) {
	        return country1.getName().compareTo(country2.getName());
	    }
}
