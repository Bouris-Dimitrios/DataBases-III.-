package countriesrelationtransofrmator;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.List;
public class OutputWriter {
	private PrintWriter writer;
	private final String fileName = "CountryRelation.txt";
	private List <EUCountry>countries;
	
	public OutputWriter(List<EUCountry> countries){
		try {	
			this.countries = countries;
			openFile();
			writeCountriesRelation();
			closeFile();
		} catch (Exception exceptionHandler) {
			System.out.println("Exception : " + exceptionHandler.getMessage());
		}
	}

	private void writeCountriesRelation(){
		for(EUCountry iter : countries)
			writer.println(iter.getStringWithAllData());
	}
	
	private void  openFile()throws IOException{
		try {
			writer = new PrintWriter(fileName, "UTF-8");
		} catch (Exception exceptionHandler) {
			System.out.println("Exception : " + exceptionHandler.getMessage());
		}
	}
	
	private void closeFile() throws IOException{
		writer.close();
	}
}
