package countriesrelationtransofrmator;
import java.io.BufferedReader;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class EUcountriesParser {
	private static final int NUMOFHEADERLINES = 3;
	private BufferedReader reader;
	final String path = "/home/nikospaxos/Desktop/king/data.csv";
	private  HashSet <String> EUCountriesNames;
	private String currentLine;
	private  String currentCountry;
	private LinkedHashMap <String,EUCountry> EUCountries;
	private String currentCountryCode;
	
	public EUcountriesParser(){
		try{
		EUCountries = new LinkedHashMap<String,EUCountry>();
		openFile();
		initializeEUNames();
		parsefEUcountriesFromBulkData();
		closeFile();
		}catch(Exception exception){
			exception.printStackTrace();
		}
	}
	
	private void  openFile()throws IOException{
		reader = new BufferedReader(new FileReader(path));
	}
	
	private void initializeEUNames(){
		EUCountriesNames = new HashSet();	
		EUCountriesNames.add("Greece");		EUCountriesNames.add("Italy"); 
		EUCountriesNames.add("Germany");	EUCountriesNames.add("Austria");
		EUCountriesNames.add("Belgium");	EUCountriesNames.add("Finland");
		EUCountriesNames.add("Bulgaria");	EUCountriesNames.add("Croatia");
		EUCountriesNames.add("Cyprus");		EUCountriesNames.add("Czech Republic");
		EUCountriesNames.add("Denmark");	EUCountriesNames.add("Estonia");
		EUCountriesNames.add("France");		EUCountriesNames.add("Hungary");
		EUCountriesNames.add("Ireland");	EUCountriesNames.add("Latvia");
		EUCountriesNames.add("Lithuania");	EUCountriesNames.add("Malta");
		EUCountriesNames.add("Luxembourg");	EUCountriesNames.add("Netherlands");
		EUCountriesNames.add("Poland");		EUCountriesNames.add("Portugal");
		EUCountriesNames.add("Romania");	EUCountriesNames.add("Slovak Republic");
		EUCountriesNames.add("Slovenia");	EUCountriesNames.add("Spain");
		EUCountriesNames.add("Sweden");		EUCountriesNames.add("United Kingdom");	
	}	
	
	private void parsefEUcountriesFromBulkData()throws Exception{
		readHeader();
		while((currentLine = reader.readLine()) != null)
			checkIfCountryIsinEUandParseIt();
	}
	
	private void readHeader()throws IOException{
		for(int i =0 ; i<NUMOFHEADERLINES; i++)
			readLine();
	}	
	
	private void checkIfCountryIsinEUandParseIt(){
		extractNameOfCountryFromReadLine();
		if(isCountryInEU())
			addCountryToEUCountryList();
	}
	
	private void readLine()throws IOException{
		reader.readLine();
	}
	
	private void extractNameOfCountryFromReadLine(){
		String [] attributes = currentLine.split(",");
		attributes[0] = attributes[0].replace("\"", "");
		currentCountry = attributes[0];
		currentCountryCode = attributes[1];
	}
	
	private boolean isCountryInEU(){
		if(EUCountriesNames.contains(currentCountry)){
			return true;
		}
		return false;	
	}
	
	private void addCountryToEUCountryList(){
		EUCountries.put(currentCountry, new EUCountry(currentCountry,currentCountryCode));
	}
	
	private void closeFile()throws IOException{
		reader.close();
	}

	
	public List getCountryList(){
		 	List countries = createCountryList();
		    countries = sortListAlphabeticlyByName(countries);
		    setCountryIds(countries);
		    return countries;
	}
	
	private List createCountryList(){
		List countries = new ArrayList<EUCountry>();
		Iterator it = EUCountries.entrySet().iterator();
	    while (it.hasNext()) {
	        Map.Entry pair = (Map.Entry)it.next();
	        EUCountry country = (EUCountry)pair.getValue();
	        countries.add(country);
	        it.remove(); // avoids a ConcurrentModificationException
	    }
	    return countries;
	}
	
	private List sortListAlphabeticlyByName(List countries){
		  Collections.sort(countries,new CustomComparator() );
		  return countries;
	}
	
	private void  setCountryIds(List<EUCountry> countries){
		for(int i =0 ;i<countries.size();i++ )
			countries.get(i).setId(i);
	}



}
