package countriesrelationtransofrmator;

public class EUCountry {
	private int id;
	private String name;
	private String code;
	
	public EUCountry(String name, String code){
		this.name = name;
		this.code = code;
	}
	
	public int getId(){
		return id;
	}
	
	public String getCode(){
		return code;
	}
	
	public String getName(){
		return name;
	}
	
	public void print(){
		System.out.println(id+ " , " + name + " , " + code);
	}
	
	public void setId(int id){
		this.id = id;
	}
	public String getStringWithAllData(){
		return id + "@" + name + "@" + code;
	}
}