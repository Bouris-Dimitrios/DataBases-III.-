package countriesrelationtransofrmator;
import java.util.ArrayList;
import java.util.List;


public class CountriesRelationTransformer {

	public static List<EUCountry> main(String[] args){
		EUcountriesParser parser = new EUcountriesParser();
		List<EUCountry> countriesList = parser.getCountryList();
		OutputWriter writer = new OutputWriter(countriesList);
		return countriesList;
	}
}
