package measurementsrelationtransformator;

public class MeasurementsRelationAttributes {
	private int countryId;
	private int indicatorId;
	private int year;
	private float value;
	
	public MeasurementsRelationAttributes(int countryId, int indicatorId, int year,
			float value){
		this.countryId = countryId;
		this.indicatorId = indicatorId;
		this.year = year;
		this.value = value;
	}

	public String getStringWithAllData(){
		return  countryId + "@"+ indicatorId +"@"+ year + "@"+value ;
	}
}
