package measurementsrelationtransformator;

import indicatorrelationstransformator.Indicator;

import java.io.BufferedReader;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import countriesrelationtransofrmator.EUCountry;

public class MeasurementsRelationParser {
	
	private static final int NUMOFHEADERLINES = 3;
	private BufferedReader reader;
	final String path = "/home/nikospaxos/Desktop/king/data.csv";
	private  HashSet <String> EUCountriesNames;
	private static List<EUCountry> countries;
	private static List<Indicator> indicators;
	private String currentLine;
	private  String currentCountry;
	private  String currentIndicatorName;
	private List<MeasurementsRelationAttributes> attributes;
	private String currentCountryCode;
	
	public MeasurementsRelationParser(List<EUCountry> countries, List<Indicator> indicators ){
		try{
			this.countries = countries;
			this.indicators = indicators;
			attributes = new ArrayList<MeasurementsRelationAttributes>();
			initializeEUNames();
			
			openFile();
			parseData();
			closeFile();
		
		}catch(Exception exception){
			exception.printStackTrace();
		}
	}
	public List<MeasurementsRelationAttributes> getAttributesList(){
		return attributes;
	}
	
	private void initializeEUNames(){
		EUCountriesNames = new HashSet();	
		EUCountriesNames.add("Greece");		EUCountriesNames.add("Italy"); 
		EUCountriesNames.add("Germany");	EUCountriesNames.add("Austria");
		EUCountriesNames.add("Belgium");	EUCountriesNames.add("Finland");
		EUCountriesNames.add("Bulgaria");	EUCountriesNames.add("Croatia");
		EUCountriesNames.add("Cyprus");		EUCountriesNames.add("Czech Republic");
		EUCountriesNames.add("Denmark");	EUCountriesNames.add("Estonia");
		EUCountriesNames.add("France");		EUCountriesNames.add("Hungary");
		EUCountriesNames.add("Ireland");	EUCountriesNames.add("Latvia");
		EUCountriesNames.add("Lithuania");	EUCountriesNames.add("Malta");
		EUCountriesNames.add("Luxembourg");	EUCountriesNames.add("Netherlands");
		EUCountriesNames.add("Poland");		EUCountriesNames.add("Portugal");
		EUCountriesNames.add("Romania");	EUCountriesNames.add("Slovak Republic");
		EUCountriesNames.add("Slovenia");	EUCountriesNames.add("Spain");
		EUCountriesNames.add("Sweden");		EUCountriesNames.add("United Kingdom");	
	}	
	
	private boolean isCountryInEU(){
		if(EUCountriesNames.contains(currentCountry)){
			return true;
		}
		return false;	
	}
	
	private void  openFile()throws IOException{
		reader = new BufferedReader(new FileReader(path));
	}
	
	private void parseData()throws Exception{
		readHeader();
		while((currentLine = reader.readLine()) != null)
			checkIfCountryIsinEUandParseData();
	}
	
	private void readHeader()throws IOException{
		for(int i =0 ; i<NUMOFHEADERLINES; i++)
			readLine();
	}	

	private void readLine()throws IOException{
		reader.readLine();
	}
	
	private void closeFile()throws IOException{
		reader.close();
	}
	
	private void extractNameOfCountryFromReadLine(){
		String split[] = currentLine.split("\"");
		currentCountry = split[1];
	}
	
	private void extractNameOfIndicatorFromReadLine(){
		String split[] = currentLine.split("\"");
		currentIndicatorName = split[5];
	}
	
	private void checkIfCountryIsinEUandParseData(){
		extractNameOfCountryFromReadLine();
		extractNameOfIndicatorFromReadLine();
		if( isCountryInEU() )
			extractDataFromLine();
	}
	
	private void extractDataFromLine(){
		String splittedData[] = currentLine.split("\"");
		int year = 1960;
		for(int i=9; i< splittedData.length; i += 2){
			if( ! splittedData[i].equals(""))
				attributes.add(new MeasurementsRelationAttributes(getCountryCode(),
						getIndicatorCode(),year,
						Float.parseFloat(splittedData[i])));
			year++;
		}
	}
	
	private int getCountryCode(){
		for(EUCountry it : countries)
			if ( currentCountry.equals(it.getName()) )
				return it.getId();			
		return -1;
	}
	
	private int getIndicatorCode(){
		for(Indicator it : indicators)
			if ( currentIndicatorName.equals(it.getName()))
					return it.getId();
		return -1;
	}

}