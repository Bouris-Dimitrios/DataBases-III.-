package measurementsrelationtransformator;

import java.util.List;

import indicatorrelationstransformator.Indicator;
import indicatorrelationstransformator.IndicatorsTransformation;
import countriesrelationtransofrmator.CountriesRelationTransformer;
import countriesrelationtransofrmator.EUCountry;

public class MeasurementsRelationTransformator {
//	private static List<EUCountry> countries;
	//private static List<Indicator> indicators;
	
	public static void main(String [] args){
		List<MeasurementsRelationAttributes> measurementsAttributes;
		MeasurementsRelationParser parser = new MeasurementsRelationParser
				(CountriesRelationTransformer.main(args),
						IndicatorsTransformation.main(args));
		measurementsAttributes = parser.getAttributesList();
		OutputWriter writer = new OutputWriter(measurementsAttributes);
	}
}
