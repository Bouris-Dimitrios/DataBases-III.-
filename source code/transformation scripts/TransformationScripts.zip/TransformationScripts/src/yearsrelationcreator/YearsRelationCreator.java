package yearsrelationcreator;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class YearsRelationCreator {
	private static  List<Year> years;
	
	public YearsRelationCreator(){
		years = new ArrayList<Year>();
		createYears();
	}
	
	private String getDateTime(int currentYear){
		return currentYear + ":01:01";
	}
	private String getHalfDecade(int currentYear){
		String halfDecade;
		int threeFirstDigits = currentYear /10;
		int halfDecadeYear = currentYear % 10;
		if(halfDecadeYear < 5  )
			halfDecade = threeFirstDigits + "0 - "+ threeFirstDigits + "4";
		else
			halfDecade = threeFirstDigits + "5 - " + threeFirstDigits + "9";
		return halfDecade;
	}
	
	private String getDecade(int currentYear){
		int threeFirstDigits = currentYear /10;
		return threeFirstDigits + "0 - " + threeFirstDigits + "9"; 
	}
	
	private String getDoubleDecade(int currentYear){
		String doubleDecade;
		int doubleDecadeYear = currentYear % 20;
		int firstYearOfDoubleDecade = currentYear - doubleDecadeYear;
		doubleDecade =  firstYearOfDoubleDecade + " - " + 
					(firstYearOfDoubleDecade + 19);
		return doubleDecade ;
	}
	private void  createYears() {
		for(int i =1960 ; i < 2015;i++)
			years.add( new Year(i,getDateTime(i),getHalfDecade(i),getDecade(i),
						getDoubleDecade(i)) );
		
	}
	public static void main(String [] args){
		YearsRelationCreator yearsCreator  = new YearsRelationCreator();
		OutputWriter writer = new OutputWriter(years);
	}
}
