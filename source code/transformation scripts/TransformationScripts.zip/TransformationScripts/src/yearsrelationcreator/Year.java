package yearsrelationcreator;

public class Year {
	int id;
	String dateTime;
	String halfDecade;
	String decade;
	String doubleDecade;
	
	public Year(int id,	String dateTime,String halfDecade,String decade,
			String doubleDecade){
		this.id =  id;
		this.dateTime = dateTime;
		this.decade = decade;
		this.halfDecade = halfDecade;
		this.doubleDecade = doubleDecade;
	}
	
	public String getStringWithAllData(){
		return id +"@" + dateTime + "@" + halfDecade + "@" + decade + "@" + doubleDecade ;
	}
}
