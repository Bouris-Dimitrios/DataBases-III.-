package yearsrelationcreator;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.List;

public class OutputWriter {
	private PrintWriter writer;
	private final String fileName = "yearsRelation.txt";
	private List <Year>attributes;
	
	public OutputWriter(List<Year> years){
		try {	
			this.attributes = years;
			openFile();
			writeCountriesRelation();
			closeFile();
		}catch(Exception exceptionHandler){
			System.out.println("Exception : " + exceptionHandler.getMessage());
		}
	}

	private void writeCountriesRelation(){
		for(Year iter : attributes)
			writer.println(iter.getStringWithAllData());
	}
	
	private void  openFile()throws IOException{
		try {
			writer = new PrintWriter(fileName, "UTF-8");
		} catch (Exception exceptionHandler) {
			System.out.println("Exception : " + exceptionHandler.getMessage());
		}
	}
	
	private void closeFile() throws IOException{
		writer.close();
	}
}
