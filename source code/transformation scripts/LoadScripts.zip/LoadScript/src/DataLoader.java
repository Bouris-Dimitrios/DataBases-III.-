import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DataLoader {
	private Connection connection = null;
	private PreparedStatement statement = null;
	private String loadCountriesQuery;
	private String loadIndicatorsQuery;
	private String loadYearsQuery;
	private String loadMeasurementsQuery;
	
	public DataLoader(){
		try{
			initialize();
			createLoadQueries();
			
		} catch (SQLException ex) {
		    System.out.println("SQLException: " + ex.getMessage());
		    System.out.println("SQLState: " + ex.getSQLState());
		    System.out.println("VendorError: " + ex.getErrorCode());
		}
	}
	
	public void  loadDataInDatabase(){
		try{
			statement = connection.prepareStatement(loadCountriesQuery);
			statement.executeQuery();
			statement = connection.prepareStatement(loadIndicatorsQuery);
			statement.executeQuery();
			statement = connection.prepareStatement(loadYearsQuery);
			statement.executeQuery();
			statement = connection.prepareStatement(loadMeasurementsQuery);
			statement.executeQuery();
			statement.close();
			
		}catch (SQLException ex){
		    // handle any errors
		    System.out.println("SQLException: " + ex.getMessage());
		    System.out.println("SQLState: " + ex.getSQLState());
		    System.out.println("VendorError: " + ex.getErrorCode());
		}
	}
	
	private void createLoadQueries(){
		loadCountriesQuery = "LOAD DATA  INFILE '/var/lib/mysql/CountryRelation.txt'"
				+ " INTO TABLE  countries fields terminated by '@' lines "
				+ "terminated by '\n' ; ";
		loadIndicatorsQuery = "LOAD DATA  INFILE '/var/lib/mysql/IndicatorsRelation.txt'"
				+ " INTO TABLE  indicators fields terminated by '@' lines "
				+ "terminated by '\n' ; ";
		loadYearsQuery = "LOAD DATA  INFILE '/var/lib/mysql/yearsRelation.txt'"
				+ " INTO TABLE  years fields terminated by '@' lines "
				+ "terminated by '\n' ; ";
		loadMeasurementsQuery = "LOAD DATA  INFILE '/var/lib/mysql/HasRelation.txt'"
		+ " INTO TABLE  measurements fields terminated by '@' lines "
		+ "terminated by '\n' ; ";
		
	}
	
	private void initialize()throws SQLException{
		connection = DriverManager.getConnection("jdbc:mysql://localhost"
			+ "/SocialProtectionAndLabor?" + "user=root&password=cs112038");
	}
	
	public static void main(String[] args) {
		DataLoader dataLoader = new DataLoader();
		dataLoader.loadDataInDatabase();

	}

}
