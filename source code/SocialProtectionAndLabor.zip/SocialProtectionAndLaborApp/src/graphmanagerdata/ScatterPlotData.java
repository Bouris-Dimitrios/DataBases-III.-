package graphmanagerdata;

import java.util.List;
import java.util.Map;

import javafx.scene.chart.XYChart.Series;

public class ScatterPlotData extends GraphData {
    private List<Series<Number, Number>> series;
    private String indicator1;
    private String indicator2;

    public ScatterPlotData(List<Series<Number, Number>> series,
	    String indicator1, String indicator2) {
	this.series = series;
	this.indicator1 = indicator1;
	this.indicator2 = indicator2;
    }

    public List<Series<Number, Number>> getSeries() {
	return series;
    }

    public String getIndicator1() {
	return indicator1;
    }

    public String getIndicator2() {
	return indicator2;
    }

    @Override
    public List<String> getSelectedYears() {
	// TODO Auto-generated method stub
	return null;
    }

    @Override
    public Map<String, Series<String, Number>> getAllSeries() {
	// TODO Auto-generated method stub
	return null;
    }
}
