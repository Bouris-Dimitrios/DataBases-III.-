package graphmanagerdata;

import java.util.List;
import java.util.Map;

import javafx.scene.chart.XYChart.Series;

public class GeneralData extends GraphData {
    private List<String> selectedYears;
    private Map<String, Series<String, Number>> series;

    public GeneralData(List<String> selectedYears,
	    Map<String, Series<String, Number>> allSeries) {
	series = allSeries;
	this.selectedYears = selectedYears;
    }

    public List<String> getSelectedYears() {
	return selectedYears;
    }

    public Map<String, Series<String, Number>> getAllSeries() {
	return series;
    }

    @Override
    public List<Series<Number, Number>> getSeries() {
	// TODO Auto-generated method stub
	return null;
    }
}
