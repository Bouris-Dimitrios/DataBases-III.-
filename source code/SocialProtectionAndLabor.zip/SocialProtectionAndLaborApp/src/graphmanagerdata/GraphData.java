package graphmanagerdata;

import java.util.List;
import java.util.Map;

import javafx.scene.chart.XYChart.Series;

public abstract class GraphData {

    public abstract List<String> getSelectedYears();

    public abstract Map<String, Series<String, Number>> getAllSeries();

    public abstract List<Series<Number, Number>> getSeries();

    public String getIndicator1() {
	return " ";
    };

    public String getIndicator2() {
	return " ";
    }

}
