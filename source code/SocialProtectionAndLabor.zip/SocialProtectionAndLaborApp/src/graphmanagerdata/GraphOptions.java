package graphmanagerdata;

import java.util.ArrayList;
import java.util.List;

import javafx.collections.ObservableList;

public class GraphOptions {
    private List<String> selectedIndicators;
    private List<String> selectedCountries;
    private List<String> selectedYears;
    private String graphType;
    private String groupByYearsType;

    public GraphOptions(String fromYear, String toYear,
	    ObservableList<String> selectedIndicators,
	    ObservableList<String> selectedCountries, String graphType,
	    String groupByYearsType) {
	this.selectedIndicators = new ArrayList<String>();
	this.selectedCountries = new ArrayList<String>();
	this.selectedYears = new ArrayList<String>();
	this.selectedCountries = selectedCountries;
	this.selectedIndicators = selectedIndicators;
	this.graphType = graphType;
	this.groupByYearsType = groupByYearsType;
	createYearsList(fromYear, toYear);

    }

    private void createYearsListPattern(int startYear, int endYear, int range) {
	startYear -= startYear % range;
	for (int i = startYear; i <= endYear; i += (range - 1)) {
	    selectedYears.add(startYear + " - " + (startYear + (range - 1)));
	    startYear += range;
	    i++;
	}
    }

    private void createYearsList(String fromYear, String toYear) {

	int startYear = 0, endYear = 0;
	try {
	    startYear = Integer.parseInt(fromYear);
	    endYear = Integer.parseInt(toYear);
	} catch (Exception exception) {
	    System.out.println("[Exception]: " + exception.getMessage());
	}
	if (groupByYearsType.equals("Year"))
	    for (int i = startYear; i <= endYear; i++)
		selectedYears.add(String.valueOf(i));
	else if (groupByYearsType.equals("Decade"))
	    createYearsListPattern(startYear, endYear, 10);
	else if (groupByYearsType.equals("Half Decade"))
	    createYearsListPattern(startYear, endYear, 5);
	else
	    createYearsListPattern(startYear, endYear, 20);
    }

    public List<String> getSelectedIndicators() {
	return selectedIndicators;
    }

    public List<String> getSelectedCountries() {
	return selectedCountries;
    }

    public List<String> getSelectedYears() {
	return selectedYears;
    }

    public String getGraphType() {
	return graphType;
    }

    public String getGroupByYearsType() {
	return groupByYearsType;
    }
}
