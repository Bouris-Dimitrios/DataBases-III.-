package util;

import java.util.Comparator;

public class CustomComparator implements Comparator<String> {
    public int compare(String string1, String string2) {
	return string1.compareTo(string2);
    }
}