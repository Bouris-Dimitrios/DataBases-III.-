package databasehandling.queries;

public class CountriesQuery extends Query {

    public CountriesQuery() {
    }

    public String getQuery() {
	createSelectClause();
	createFromClause();
	String query = selectClause + fromClause + ";";
	return query;
    }

    protected void createSelectClause() {
	selectClause = "select c_name, c_id ";
    }

    protected void createFromClause() {
	fromClause = " from countries ";
    }
}
