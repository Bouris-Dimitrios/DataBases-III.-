package databasehandling.queries;

import java.util.List;

public class ScatterPlotQuery extends GraphQuery {

    public ScatterPlotQuery() {
		;
	}
   
	@Override
    public String getQuery() {
	createSelectClause();
	createFromClause();
	createWhereCLause();
	groupByClause = "group by view1.m_value,view2.m_value";
	orderByClause = " order by view1.c_name";
	return selectClause + fromClause + whereClause + groupByClause
		+ orderByClause + ";";
    }

    @Override
    protected void createSelectClause() {
	selectClause = "select view1.c_name, view1.i_name ,view2.i_name, view1.m_value, view2.m_value";
    }

    private void createFromClause() {
	fromClause = " from v view1, v view2";
    }

    private void createWhereCLause() {
	whereClause = " where view1.y_id = view2.y_id and view1.c_name = view2.c_name and view1.i_name <> view2.i_name ";
    }
}
