package databasehandling.queries;

import data.ReportData;

public class ReportDataQuery {

    public static String getSelectQuery() {
	return "select * " + "from reports";
    }

    public static String getInsertQuery(ReportData reportData) {
	String query = "insert Into reports(r_id,r_path,r_keyword1,r_keyword2,r_keyword3) VALUES(";
	query += "\"" + reportData.getIdProperty().getValue() + "\",\""
		+ reportData.getPathProperty().getValue() + "\",\""
		+ reportData.getKey1Property().getValue() + "\",\""
		+ reportData.getKey2Property().getValue() + "\",\""
		+ reportData.getKey3Property().getValue() + "\");";
	return query;
    }

    public static String getDeleteQuery(ReportData reportData) {
	String query = "delete from reports where r_id = "
		+ reportData.getIdProperty().getValue() + " ;";
	return query;
    }

    public static String getUpdateQuery(ReportData reportData) {
	String query = "update reports Set ";
	query += "r_id = \"" + reportData.getIdProperty().getValue()
		+ "\",r_path =\"" + reportData.getPathProperty().getValue()
		+ "\",r_keyword1= \"" + reportData.getKey1Property().getValue()
		+ "\",r_keyword2= \"" + reportData.getKey2Property().getValue()
		+ "\",r_keyword3= \"" + reportData.getKey3Property().getValue()
		+ "\" where r_id= \"" + reportData.getIdProperty().getValue()
		+ "\";";
	return query;
    }
}
