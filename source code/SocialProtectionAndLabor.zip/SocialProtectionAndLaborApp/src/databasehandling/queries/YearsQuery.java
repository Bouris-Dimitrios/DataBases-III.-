package databasehandling.queries;

public class YearsQuery extends Query {

    public YearsQuery() {
    }

    public String getQuery() {
	createSelectClause();
	createFromClause();
	String query = selectClause + fromClause + ";";
	return query;
    }

    protected void createSelectClause() {
	selectClause = "select y_id ";
    }

    protected void createFromClause() {
	fromClause = " from years ";
    }
}
