package databasehandling.queries;

import graphmanagerdata.GraphOptions;

public class QueryFactory {

    public static Query getQueryBasedOnGroupByYears(GraphOptions options) {
	if (options.getGroupByYearsType() == "Year")
	    return new ValuePerIndicatorQuery(options);
	if (options.getGroupByYearsType() == "Decade")
	    return new AverageValuePerDecadeQuery(options);
	if (options.getGroupByYearsType() == "Half Decade")
	    return new AverageValuePerHalfDecadeQuery(options);
	return new AverageValuePerTwentyYearsQuery(options);
    }
}
