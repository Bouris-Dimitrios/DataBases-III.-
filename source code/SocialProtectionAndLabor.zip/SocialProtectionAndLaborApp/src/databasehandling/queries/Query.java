package databasehandling.queries;

public abstract class Query {
    protected String query;
    protected String selectClause;
    protected String fromClause;
    protected String whereClause;
    protected String groupByClause;
    protected String orderByClause;

    public abstract String getQuery();
    protected abstract void createSelectClause();
}
