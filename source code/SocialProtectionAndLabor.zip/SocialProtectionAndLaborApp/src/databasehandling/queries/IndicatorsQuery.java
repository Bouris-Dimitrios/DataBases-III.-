package databasehandling.queries;

public class IndicatorsQuery extends Query {

    public IndicatorsQuery() {
    }

    public String getQuery() {
	createSelectClause();
	createFromClause();
	String query = selectClause + fromClause + ";";
	return query;
    }

    protected void createSelectClause() {
	selectClause = "select i_name,i_id ";
    }

    protected void createFromClause() {
	fromClause = " from indicators ";
    }
}
