package databasehandling.queries;

import graphmanagerdata.GraphOptions;

public class AverageValuePerTwentyYearsQuery extends GraphQuery {

    public AverageValuePerTwentyYearsQuery(GraphOptions options) {
	super(options.getSelectedCountries(), options.getSelectedIndicators());
	selectedYears = options.getSelectedYears();
    }

    protected void createSelectClause() {
	selectClause = "select c_name,y_doubleDecade y_id,i_name,avg(m_value) m_value ";
    }

    protected void createFromClause() {
	fromClause = "from measurements,years,countries,indicators ";
    }

    protected void addYear(int i) {
	whereClause += "y_doubleDecade = " + "\"" + selectedYears.get(i) + "\"";
    }

    public String getQuery() {
	createSelectClause();
	createFromClause();
	createWhereClause();
	groupByClause = "group by y_doubleDecade,c_name,i_name ";
	orderByClause = "order by i_name ";

	String query = selectClause + fromClause + whereClause + groupByClause
		+ orderByClause + ";";
	return query;
    }
}