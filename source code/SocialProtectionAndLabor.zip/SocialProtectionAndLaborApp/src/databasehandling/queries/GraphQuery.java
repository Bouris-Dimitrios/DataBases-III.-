package databasehandling.queries;

import java.util.List;
import mainengine.MainEngine;

public abstract class GraphQuery extends Query {

    protected List<String> selectedCountries;
    protected List<String> selectedIndicators;
    protected List<String> selectedYears;

    public GraphQuery(List<String> selectedCountries,
	    List<String> selectedIndicators) {
	this.selectedCountries = selectedCountries;
	this.selectedIndicators = selectedIndicators;
    }
    public GraphQuery(){
    	;
    }

    protected void addSelectedCountries() {
	whereClause += " and ( ";
	addCountries();
	whereClause += " )";
    }

    private void addCountries() {
	for (int i = 0; i < selectedCountries.size(); i++) {
	    addCountry(i);
	    if (i < selectedCountries.size() - 1)
		whereClause += " or ";
	}
    }

    private void addCountry(int i) {
	whereClause += "c_id = " + "\""
		+ MainEngine.getCountryId(selectedCountries.get(i)) + "\"";
    }

    protected void addYear(int i) {
	whereClause += "m_yearId = " + "\"" + selectedYears.get(i) + "\"";
    }

    protected void addSelectedIndicators() {
	whereClause += " and ( ";
	for (int i = 0; i < selectedIndicators.size(); i++) {
	    String indicator = MainEngine.getIndicatorId(selectedIndicators
		    .get(i));
	    whereClause += "i_id = \"" + indicator + "\"";
	    if (i < selectedIndicators.size() - 1)
		whereClause += " or ";
	}
	whereClause += " )";
    }

    protected void addYears() {
	for (int i = 0; i < selectedYears.size(); i++) {
	    addYear(i);
	    if (i < selectedYears.size() - 1)
		whereClause += " or ";
	}
    }

    protected void addSelectedYears() {
	whereClause += " and ( ";
	addYears();
	whereClause += " )";
    }

    protected void createWhereClause() {
	whereClause = "where m_yearId = y_id and c_id = m_countryId and m_indicatorId = i_id ";
	addSelectedCountries();
	addSelectedIndicators();
	addSelectedYears();
    }

}
