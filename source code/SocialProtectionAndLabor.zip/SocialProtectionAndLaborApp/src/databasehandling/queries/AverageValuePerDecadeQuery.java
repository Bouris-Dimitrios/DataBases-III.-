package databasehandling.queries;

import graphmanagerdata.GraphOptions;

public class AverageValuePerDecadeQuery extends GraphQuery {

    public AverageValuePerDecadeQuery(GraphOptions options) {
	super(options.getSelectedCountries(), options.getSelectedIndicators());
	selectedYears = options.getSelectedYears();

    }

    protected void createSelectClause() {
	selectClause = "select c_name,y_decade y_id,i_name,avg(m_value) m_value ";
    }

    protected void createFromClause() {
	fromClause = "from measurements,years,countries,indicators ";
    }

    protected void createWhereClause() {
	whereClause = "where m_yearId = y_id and c_id = m_countryId and m_indicatorId = i_id ";
	addSelectedCountries();
	addSelectedIndicators();
	addSelectedYears();
    }

    protected void addYear(int i) {
	whereClause += "y_decade = " + "\"" + selectedYears.get(i) + "\"";
    }

    public String getQuery() {
	createSelectClause();
	createFromClause();
	createWhereClause();
	groupByClause = "group by y_decade,c_name,i_name ";
	orderByClause = "order by i_name ";
	String query = selectClause + fromClause + whereClause + groupByClause
		+ orderByClause + ";";
	return query;
    }
}
