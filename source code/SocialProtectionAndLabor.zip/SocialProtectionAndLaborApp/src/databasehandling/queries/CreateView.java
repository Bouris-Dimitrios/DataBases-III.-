package databasehandling.queries;

public class CreateView {

    public static String createViewQuery(Query readyQuery) {
	String query;
	query = "Create view v as " + readyQuery.getQuery();
	return query;
    }

    public static String dropViewQuery() {
	String query;
	query = "drop view v ;";
	return query;
    }
}
