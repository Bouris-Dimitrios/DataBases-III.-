package databasehandling.queries;

import graphmanagerdata.GraphOptions;

public class ValuePerIndicatorQuery extends GraphQuery {

    public ValuePerIndicatorQuery(GraphOptions options) {
	super(options.getSelectedCountries(), options.getSelectedIndicators());
	selectedYears = options.getSelectedYears();
    }

    protected void createSelectClause() {
	selectClause = "select c_name,y_id,i_name,m_value  ";
    }

    protected void createFromClause() {
	fromClause = "from measurements,years,countries,indicators ";
    }

    public String getQuery() {
	createSelectClause();
	createFromClause();
	createWhereClause();
	groupByClause = "group by c_name, i_name , y_id ";
	orderByClause = "order by i_name ";
	return selectClause + fromClause + whereClause + groupByClause
		+ orderByClause + ";";
	
    }

}
