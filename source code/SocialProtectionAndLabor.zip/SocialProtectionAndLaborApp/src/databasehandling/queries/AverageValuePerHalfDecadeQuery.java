package databasehandling.queries;

import graphmanagerdata.GraphOptions;

public class AverageValuePerHalfDecadeQuery extends GraphQuery {

    public AverageValuePerHalfDecadeQuery(GraphOptions options) {
	super(options.getSelectedCountries(), options.getSelectedIndicators());
	selectedYears = options.getSelectedYears();
    }

    protected void createSelectClause() {
	selectClause = "select c_name,y_halfDecade y_id,i_name,avg(m_value) m_value ";
    }

    protected void createFromClause() {
	fromClause = "from measurements,years,countries,indicators ";
    }

    protected void addYear(int i) {
	whereClause += "y_halfDecade = " + "\"" + selectedYears.get(i) + "\"";
    }

    public String getQuery() {
	createSelectClause();
	createFromClause();
	createWhereClause();
	groupByClause = "group by y_halfDecade,c_name,i_name ";
	orderByClause = "order by i_name ";

	String query = selectClause + fromClause + whereClause + groupByClause
		+ orderByClause + ";";
	return query;
    }
}