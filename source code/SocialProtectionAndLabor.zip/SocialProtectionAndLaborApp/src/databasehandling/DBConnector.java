package databasehandling;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnector {
    private String url = "jdbc:mysql://localhost/SocialProtectionAndLabor?";
    private String userName = "root";
    private String password = "cs112038";
    private Connection connection;

    public Connection connect() {
	try {
	    connection = DriverManager.getConnection(url, userName, password);
	    return connection;
	} catch (SQLException e) {
	    e.printStackTrace();
	    return null;
	}
    }

    public void closeConnection() {
	try {
	    connection.close();
	} catch (SQLException e) {
	    e.printStackTrace();
	}
    }
}