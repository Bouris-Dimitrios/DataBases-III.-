package databasehandling;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class QueryExecutor {
    private Connection connection;
    private PreparedStatement result;
    private ResultSet resultSet;

    public QueryExecutor(Connection connection) {
	this.connection = connection;
	try {
	    result = connection.prepareStatement("");
	} catch (SQLException exception) {
	    exception.printStackTrace();
	}
    }

    public ResultSet executeQueryAndReturnResult(String query) {
	try {
	    result = connection.prepareStatement(query);
	    resultSet = result.executeQuery(query);
	} catch (SQLException exception) {
	    exception.printStackTrace();
	}
	return resultSet;
    }

    public void showErrorAlert(String title, String header, String content) {
	Alert alert = new Alert(AlertType.INFORMATION);
	alert.setTitle(title);
	alert.setHeaderText(header);
	alert.setContentText(content);
	alert.showAndWait();
    }

    public boolean executeQuery(String query) {
	try {
	    result = connection.prepareStatement(query);
	    result.executeUpdate(query);
	} catch (SQLException exception) {
	    showErrorAlert("Error Occured", "Sql Exception",
		    exception.getMessage());
	    return false;
	}
	return true;
    }

    public void close() {
	try {
	    result.close();
	} catch (SQLException e) {
	    e.printStackTrace();
	}
    }

}
