package graphmanager;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.chart.XYChart.Series;
import data.Measurement;
import databasehandling.QueryExecutor;
import databasehandling.queries.Query;
import graphmanagerdata.GeneralData;
import graphmanagerdata.GraphData;
import graphmanagerdata.GraphOptions;

public class GeneralPlotManager extends GraphManager {

    public GeneralPlotManager(GraphOptions graphOptions) {
	super(graphOptions);
    }

    @Override
    public GraphData createDataForChart(ResultSet results) {
	Map<String, Series<String, Number>> allSeries = new HashMap<String, Series<String, Number>>();
	List<Measurement> measurements = new ArrayList<Measurement>();
	readMeasurementsFromResultSet(measurements, results);
	createDataTimeLineBarChart(allSeries, measurements);
	GraphData data = new GeneralData(graphOptions.getSelectedYears(),
		allSeries);

	return data;
    }

    private void createDataTimeLineBarChart(
	    Map<String, Series<String, Number>> allSeries,
	    List<Measurement> measurements) {
	this.measurements = measurements;
	createSeriesAndAddthemToCollection(allSeries);
	fillSeriesWithValues(allSeries);
    }

    protected void createSeriesAndAddthemToCollection(
	    Map<String, Series<String, Number>> allSeries) {
	for (int i = 0; i < selectedCountries.size(); i++)
	    for (int j = 0; j < selectedIndicators.size(); j++) {
		Series<String, Number> newSerie = new Series<String, Number>();
		newSerie.setName(getSeriesName(i, j));
		allSeries.put(getSeriesName(i, j), newSerie);
	    }
    }

    private String getSeriesName(int countryIndex, int indicatorIndex) {
	return concatStrings(selectedCountries.get(countryIndex),
		selectedIndicators.get(indicatorIndex));
    }

    private String concatStrings(String country, String indicator) {
	return country + "-" + indicator;
    }

    protected void fillSeriesWithValues(
	    Map<String, XYChart.Series<String, Number>> allSeries) {
	for (int i = 0; i < measurements.size(); i++) {
	    final Measurement measurement = measurements.get(i);
	    final String key = concatStrings(measurement.getCountry(),
		    measurement.getIndicator());
	    allSeries
		    .get(key)
		    .getData()
		    .add(new Data<>(measurement.getYear(), measurement
			    .getValue()));
	}
    }

    private void readMeasurements(List<Measurement> measurements,
	    ResultSet results) throws Exception {
	while (results.next()) {
	    double value = Double.parseDouble(results.getString("m_value"));
	    Measurement newMeasurement = Measurement.createGeneralMeasurement(
		    results.getString("c_name"), results.getString("i_name"),
		    value, results.getString("y_id"));
	    measurements.add(newMeasurement);
	}
    }

    protected void readMeasurementsFromResultSet(
	    List<Measurement> measurements, ResultSet results) {
	try {
	    readMeasurements(measurements, results);

	} catch (Exception e) {
	    System.out.println(e.getMessage());
	}
    }

    @Override
    public ResultSet getResultSet(Query query, QueryExecutor executor) {
	return executor.executeQueryAndReturnResult(query.getQuery());
    }

}
