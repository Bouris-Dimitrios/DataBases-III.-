package graphmanager;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javafx.scene.chart.XYChart.Data;
import javafx.scene.chart.XYChart.Series;
import data.Measurement;
import databasehandling.QueryExecutor;
import databasehandling.queries.CreateView;
import databasehandling.queries.Query;
import databasehandling.queries.ScatterPlotQuery;
import graphmanagerdata.GraphData;
import graphmanagerdata.GraphOptions;
import graphmanagerdata.ScatterPlotData;

public class ScatterPlotManager extends GraphManager {

    public ScatterPlotManager(GraphOptions graphOptions) {
	super(graphOptions);
    }

    @Override
    public GraphData createDataForChart(ResultSet results) {
	List<Measurement> measurements = new ArrayList<Measurement>();
	readMeasurementsFromResultSet(measurements, results);
	return createScatterPlotData(measurements);
    }

    private ScatterPlotData createScatterPlotData(List<Measurement> measurements) {
	List<Series<Number, Number>> seriesList = new ArrayList<Series<Number, Number>>();
	ScatterPlotData data = null;
	String indicator1 = "";
	String indicator2 = "";
	for (int i = 0; i < selectedCountries.size(); i++) {
	    seriesList.add(new Series<Number, Number>());
	    seriesList.get(i).setName(selectedCountries.get(i));
	}
	for (Measurement measurement : measurements)
	    seriesList
		    .get(selectedCountries.indexOf(measurement.getCountry()))
		    .getData()
		    .add(new Data(measurement.getValue(), measurement
			    .getValue2()));
	try {
	    indicator1 = measurements.get(0).getIndicator();
	    indicator2 = measurements.get(0).getIndicator2();
	} catch (Exception excetpion) {
	    ;
	}
	data = new ScatterPlotData(seriesList, indicator1, indicator2);

	return data;
    }

    @Override
    protected void readMeasurementsFromResultSet(
	    List<Measurement> measurements, ResultSet results) {
	try {
	    while (results.next()) {
		double value = Double.parseDouble(results
			.getString("view1.m_value"));
		double value2 = Double.parseDouble(results
			.getString("view2.m_value"));
		Measurement newMeasurement = Measurement
			.createScatterPlotMeasurement(
				results.getString("view1.c_name"),
				results.getString("view1.i_name"), value,
				results.getString("view2.i_name"), value2);
		measurements.add(newMeasurement);
	    }
	} catch (Exception e) {
	    System.out.println(e.getMessage());
	}

    }

    @Override
    public ResultSet getResultSet(Query query, QueryExecutor executor) {
	executor.executeQuery(CreateView.createViewQuery(query));
	query = new ScatterPlotQuery();
	ResultSet results = executor.executeQueryAndReturnResult(query
		.getQuery());
	executor.executeQuery(CreateView.dropViewQuery());
	return results;
    }
}
