package graphmanager;

import graphmanagerdata.GraphData;
import graphmanagerdata.GraphOptions;

import java.sql.ResultSet;
import java.util.List;

import data.Measurement;
import databasehandling.QueryExecutor;
import databasehandling.queries.Query;


public abstract class GraphManager {
    protected GraphOptions graphOptions;
    protected List<Measurement> measurements;
    protected List<String> selectedCountries;
    protected List<String> selectedIndicators;

    public GraphManager(GraphOptions graphOptions) {
	this.graphOptions = graphOptions;
    }

    public GraphOptions getGraphOptions() {
	return graphOptions;
    }

    public void setSelectedCountries(List<String> selectedCountries) {
	this.selectedCountries = selectedCountries;
    }

    public void setSelectedIndicators(List<String> selectedIndicators) {
	this.selectedIndicators = selectedIndicators;
    }

    public abstract ResultSet getResultSet(Query query, QueryExecutor executor);

    public abstract GraphData createDataForChart(ResultSet results);

    protected abstract void readMeasurementsFromResultSet(
	    List<Measurement> measurements, ResultSet results);

}
