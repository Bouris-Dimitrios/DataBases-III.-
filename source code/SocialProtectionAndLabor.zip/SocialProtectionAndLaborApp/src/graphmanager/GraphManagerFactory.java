package graphmanager;

import graphmanagerdata.GraphOptions;

public class GraphManagerFactory {

    public static GraphManager createNewGraphManager(GraphOptions options) {
	if (options.getGraphType() == "Scatter Plot")
	    return new ScatterPlotManager(options);
	return new GeneralPlotManager(options);
    }
}
