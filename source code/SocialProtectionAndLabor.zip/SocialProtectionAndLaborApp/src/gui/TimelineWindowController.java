package gui;

import graphmanagerdata.GraphData;

import java.util.List;
import java.util.Map;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart.Series;

public class TimelineWindowController {

    @FXML
    private LineChart<String, Number> lineChart;

    @FXML
    private CategoryAxis xAxis;

    private ObservableList<String> years = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
    }

    public void setTimeLineData(GraphData data) {
	List<String> selectedYears = data.getSelectedYears();
	Map<String, Series<String, Number>> allSeries = data.getAllSeries();
	for (int i = 0; i < selectedYears.size(); i++)
	    years.add(selectedYears.get(i));
	xAxis.setCategories(years);

	for (Series<String, Number> value : allSeries.values()) {
	    lineChart.getData().add(value);
	}
    }
}