package gui;

import graphmanagerdata.GraphData;

import java.io.IOException;

import data.ReportData;
import mainengine.MainEngine;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.ScatterChart;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class GuiMain extends Application {

    private Stage primaryStage;
    private AnchorPane mainWindow;
    private static MainEngine engine;
    private MainWindowController mainWindowController;

    @Override
    public void start(Stage primaryStage) {
	this.primaryStage = primaryStage;
	this.primaryStage.setTitle("AddressApp");

	initRootLayout();
    }


    public void initRootLayout() {
	try {
	    FXMLLoader loader = new FXMLLoader();
	    loader.setLocation(GuiMain.class.getResource("MainWindow.fxml"));
	    mainWindow = (AnchorPane) loader.load();
	    Scene scene = new Scene(mainWindow);
	    primaryStage.setScene(scene);
	    mainWindowController = loader.getController();
	    mainWindowController.setMainApp(this, engine);
	    primaryStage.show();
	    mainWindowController.setCountriesList(engine.getCountriesList());
	    mainWindowController.setIndicatorsList(engine.getIndicators());
	    mainWindowController.setYearsList(engine.getYears());

	} catch (IOException e) {
	    e.printStackTrace();
	}
    }

    public void showTimelineWindow(GraphData data) {
	try {
	    FXMLLoader loader = new FXMLLoader();
	    loader.setLocation(GuiMain.class.getResource("ChartWindow.fxml"));
	    AnchorPane page = (AnchorPane) loader.load();
	    Stage dialogStage = new Stage();
	    dialogStage.setTitle("Timeline Chart");
	    dialogStage.initModality(Modality.WINDOW_MODAL);
	    dialogStage.initOwner(primaryStage);
	    Scene scene = new Scene(page);
	    dialogStage.setScene(scene);

	    TimelineWindowController controller = loader.getController();
	    controller.setTimeLineData(data);
	    dialogStage.show();

	} catch (IOException e) {
	    e.printStackTrace();
	}
    }

    public void showBarChartWindow(GraphData data) {
	try {
	    FXMLLoader loader = new FXMLLoader();
	    loader.setLocation(GuiMain.class.getResource("BarChartWindow.fxml"));
	    AnchorPane page = (AnchorPane) loader.load();
	    Stage dialogStage = new Stage();
	    dialogStage.setTitle("Bar Chart");
	    dialogStage.initModality(Modality.WINDOW_MODAL);
	    dialogStage.initOwner(primaryStage);
	    Scene scene = new Scene(page);
	    dialogStage.setScene(scene);
	    BarChartWindowController controller = loader.getController();
	    controller.setBarChartData(data);
	    dialogStage.show();

	} catch (IOException e) {
	    e.printStackTrace();
	}
    }

    public void showScatterPlotWindow(GraphData graphData, String title) {
	Stage stage = new Stage();
	stage.setTitle("Scatter Chart");
	final NumberAxis xAxis = new NumberAxis();
	final NumberAxis yAxis = new NumberAxis();
	final ScatterChart<Number, Number> scatterPlot = new ScatterChart<Number, Number>(
		xAxis, yAxis);
	xAxis.setLabel(graphData.getIndicator1());
	yAxis.setLabel(graphData.getIndicator2());
	scatterPlot.getData().addAll(graphData.getSeries());
	scatterPlot.setTitle(title);
	Scene scene = new Scene(scatterPlot, 800, 800);
	stage.setScene(scene);
	stage.show();
    }

    public void showReportDetailsWindow(ReportData data, boolean insertMode) {
	FXMLLoader loader = new FXMLLoader();
	loader.setLocation(GuiMain.class
		.getResource("ReportDetailsWindow.fxml"));
	AnchorPane page = null;
	try {
	    page = (AnchorPane) loader.load();
	} catch (IOException e) {
	    e.printStackTrace();
	}
	Stage dialogStage = new Stage();
	dialogStage.setTitle("Report Details");
	dialogStage.initModality(Modality.WINDOW_MODAL);
	dialogStage.initOwner(primaryStage);
	Scene scene = new Scene(page);
	dialogStage.setScene(scene);
	ReportDetailsWindowController controller = loader.getController();
	controller.setMainWindow(mainWindowController, dialogStage);
	controller.setReportData(data, insertMode);
	dialogStage.show();
    }

    public Stage getPrimaryStage() {
	return primaryStage;
    }

    public static void main(String[] args) {
	engine = new MainEngine();
	launch(args);
    }
}