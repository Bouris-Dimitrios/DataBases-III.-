package gui;

import graphmanagerdata.GraphData;
import java.util.List;
import java.util.Map;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart.Series;

public class BarChartWindowController {

    @FXML
    private BarChart<String, Number> barChart;

    @FXML
    private CategoryAxis xAxis;
    @FXML
    private NumberAxis yAxis = new NumberAxis();
    private ObservableList<String> years = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
    }
    public void setBarChartData(GraphData data) {

	List<String> selectedYears = data.getSelectedYears();
	Map<String, Series<String, Number>> allSeries = data.getAllSeries();
	for (int i = 0; i < selectedYears.size(); i++)
	    years.add(selectedYears.get(i));
	xAxis.setCategories(years);
	barChart.setTitle("Bar Chart");
	for (Series<String, Number> value : allSeries.values())
	    barChart.getData().add(value);

    }
}