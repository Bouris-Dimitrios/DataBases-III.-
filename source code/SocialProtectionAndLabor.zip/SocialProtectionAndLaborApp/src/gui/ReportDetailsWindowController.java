package gui;

import data.ReportData;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class ReportDetailsWindowController {

    @FXML
    private TextField path;
    @FXML
    private TextField id;
    @FXML
    private TextField key1;
    @FXML
    private TextField key2;
    @FXML
    private TextField key3;
    private boolean insertMode;
    private MainWindowController mainWindow;
    private Stage dialogStage;

    @FXML
    private void initialize() {
	insertMode = false;
    }

    public void showErrorAlert(String title, String header, String content) {
	Alert alert = new Alert(AlertType.INFORMATION);
	
	alert.setTitle(title);
	alert.setHeaderText(header);
	alert.setContentText(content);
	alert.showAndWait();
    }

    public void setMainWindow(MainWindowController mainWindow, Stage dialogStage) {
	this.mainWindow = mainWindow;
	this.dialogStage = dialogStage;
    }

    public void setReportData(ReportData data, boolean insertMode) {
	this.insertMode = insertMode;
	if (data == null)
	    return;
	path.setText(data.getPathProperty().getValue());
	id.setText(data.getIdProperty().getValue());
	key1.setText(data.getKey1Property().getValue());
	key2.setText(data.getKey2Property().getValue());
	key3.setText(data.getKey3Property().getValue());
    }

    public void handleOkButton() {
	String idField = id.getText();
	int idInteger = 0;

	try {
	    idInteger = Integer.parseInt(idField);
	} catch (Exception exception) {
	    showErrorAlert("Error Occured", "Error in id field",
		    "id must be number");
	    return;
	}
	ReportData data = new ReportData(String.valueOf(idInteger),
		path.getText(), key1.getText(), key2.getText(), key3.getText());
	if (insertMode)
	    mainWindow.insertReport(data);
	else
	    mainWindow.updateReport(data);

	dialogStage.close();

    }

    public void handleCancelButton() {
	dialogStage.close();
    }
}