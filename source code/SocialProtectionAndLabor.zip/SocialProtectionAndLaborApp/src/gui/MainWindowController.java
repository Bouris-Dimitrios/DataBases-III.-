package gui;


import graphmanagerdata.GraphOptions;
import util.CustomComparator;

import java.util.List;
import java.util.Map;

import data.Country;
import data.Indicator;
import data.ReportData;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import mainengine.MainEngine;

public class MainWindowController {
    private GuiMain mainApp;
    private MainEngine engine;
    private CustomComparator comparator;
    @FXML
    private ListView<String> countriesListView;
    @FXML
    private ListView<String> indicatorsListView;
    @FXML
    private ListView<String> selectedCountriesListView;
    @FXML
    private ListView<String> selectedIndicatorsListView;
    @FXML
    private ComboBox<String> fromYearComboBox;
    @FXML
    private ComboBox<String> toYearComboBox;
    @FXML
    private ComboBox<String> graphsComboBox;
    @FXML
    private ComboBox<String> groupByComboBox;
    @FXML
    private TableView<ReportData> reportTable;
    @FXML
    private TableColumn<ReportData, String> idColumn;
    @FXML
    private TableColumn<ReportData, String> pathColumn;
    @FXML
    private TableColumn<ReportData, String> key1Column;
    @FXML
    private TableColumn<ReportData, String> key2Column;
    @FXML
    private TableColumn<ReportData, String> key3Column;

    private String clickedCountry;
    private String clickedIndicator;
    private ReportData clickedReport;

    public ObservableList<String> indicatorsData = FXCollections
	    .observableArrayList();
    public ObservableList<String> countriesData = FXCollections
	    .observableArrayList();
    public ObservableList<String> selectedIndicators = FXCollections
	    .observableArrayList();
    public ObservableList<String> selectedCountries = FXCollections
	    .observableArrayList();
    public ObservableList<String> years = FXCollections.observableArrayList();
    public ObservableList<String> graphTypes = FXCollections
	    .observableArrayList();
    public ObservableList<String> groupByTypes = FXCollections
	    .observableArrayList();

    public MainWindowController() {
    }

    public void showErrorAlert(String title, String header, String content) {
	Alert alert = new Alert(AlertType.INFORMATION);
	alert.setTitle(title);
	alert.setHeaderText(header);
	alert.setContentText(content);
	alert.showAndWait();

    }

    private void initColumnPropertiesForReportTable() {
	idColumn.setCellValueFactory(cellData -> cellData.getValue()
		.getIdProperty());
	pathColumn.setCellValueFactory(cellData -> cellData.getValue()
		.getPathProperty());
	key1Column.setCellValueFactory(cellData -> cellData.getValue()
		.getKey1Property());
	key2Column.setCellValueFactory(cellData -> cellData.getValue()
		.getKey2Property());
	key3Column.setCellValueFactory(cellData -> cellData.getValue()
		.getKey3Property());
    }

    @FXML
    private void initialize() {
	graphTypes.addAll("Timeline / Trendline", "Bar Chart", "Scatter Plot");
	graphsComboBox.getItems().addAll(graphTypes);
	groupByTypes.addAll("Year", "Half Decade", "Decade", "Twenty Years");
	groupByComboBox.getItems().addAll(groupByTypes);
	clickedCountry = clickedIndicator = "";
	comparator = new CustomComparator();
	initColumnPropertiesForReportTable();
	clickedReport = null;
    }

    @FXML
    public void handleInsertButton() {
	mainApp.showReportDetailsWindow(null, true);
	clickedReport = null;
    }

    @FXML
    public void handleDeleteButton() {
	if (clickedReport == null)
	    return;
	engine.deleteReport(clickedReport);
	reportTable.setItems(engine.getListForReportTable());
	clickedReport = null;
    }

    @FXML
    public void handleUpdateButton() {
	if (clickedReport == null)
	    return;
	mainApp.showReportDetailsWindow(clickedReport, false);
	clickedReport = null;
    }

    public void insertReport(ReportData data) {
	engine.insertReport(data);
	reportTable.setItems(engine.getListForReportTable());
    }

    public void updateReport(ReportData data) {
	engine.updateReport(data);
	reportTable.setItems(engine.getListForReportTable());
    }

    public boolean handleUpdateReport(ReportData data) {
	boolean updateResult = engine.insertReport(data);
	reportTable.setItems(engine.getListForReportTable());
	return updateResult;
    }

    @FXML
    public void handleClickOnSelectedReportListView() {
	try {
	    clickedReport = (ReportData) reportTable.getSelectionModel()
		    .getSelectedItem();
	} catch (Exception exception) {
	    System.out.println(exception.getMessage());
	}
    }

    @FXML
    public void handleGenerateGraphs() {
	String graphChoise = "";
	String startingYear = "";
	String endingYear = "";
	String groupByYearChoise = "";
	String errorMessage = "";
	boolean error = false;
	try {
	    graphChoise = graphsComboBox.getValue().toString();

	} catch (NullPointerException exception) {
	    errorMessage += "- Please select type of graph!\n";
	    error = true;
	}

	try {
	    groupByYearChoise = groupByComboBox.getValue().toString();

	} catch (NullPointerException exception) {
	    errorMessage += "- Please select group by Year!\n";
	    error = true;
	}
	try {
	    startingYear = fromYearComboBox.getValue().toString();
	    endingYear = toYearComboBox.getValue().toString();
	    if (Integer.parseInt(startingYear) >= Integer.parseInt(endingYear)) {
		errorMessage += "- Ending year must be greater than Starting Year\n";
		error = true;
	    }
	} catch (NullPointerException exception) {
	    errorMessage += "- Please select year Range\n";
	    error = true;
	}
	if (selectedCountries.size() == 0) {
	    errorMessage += "- Please select a Country\n";
	    error = true;
	}
	if (selectedIndicators.size() == 0) {
	    errorMessage += "- Please select an Indicator\n";
	    error = true;
	}
	if (graphChoise == "Scatter Plot" && selectedIndicators.size() != 2) {
	    errorMessage += "- Scatter Plot can contain only two Indicators \n";
	    error = true;
	}
	if (error) {
	    showErrorAlert("Error", "Something has gone wrong", errorMessage);
	    return;
	}

	GraphOptions graphOptions = new GraphOptions(fromYearComboBox
		.getValue().toString(), toYearComboBox.getValue().toString(),
		selectedIndicators, selectedCountries, graphChoise,
		groupByYearChoise);

	engine.createGraphManager(graphOptions, selectedCountries,
		selectedIndicators);

	if (graphChoise == "Timeline / Trendline")
	    mainApp.showTimelineWindow(engine.getDataForChart());
	if (graphChoise == "Bar Chart")
	    mainApp.showBarChartWindow(engine.getDataForChart());
	if (graphChoise == "Scatter Plot"){
	    String title = "range: ' " + startingYear + " - " + endingYear + 
		    " ' , group by: " + groupByYearChoise ;
	    mainApp.showScatterPlotWindow(engine.getDataForChart(),title); 
	}

    }

    public void setMainApp(GuiMain mainApp, MainEngine engine) {
	this.mainApp = mainApp;
	this.engine = engine;
	reportTable.setItems(engine.getListForReportTable());
    }

    public void setCountriesList(Map<String, Country> countries) {
	for (Country value : countries.values())
	    countriesData.add(value.getName());
	countriesListView.setItems((ObservableList<String>) countriesData);
    }

    public void setIndicatorsList(Map<String, Indicator> indicators) {
	for (Indicator value : indicators.values())
	    indicatorsData.add(value.getName());
	indicatorsListView.setItems((ObservableList<String>) indicatorsData);
    }

    public void setYearsList(List<String> yearsList) {
	for (int i = 0; i < yearsList.size(); i++)
	    years.add(yearsList.get(i));
	fromYearComboBox.getItems().addAll(years);
	toYearComboBox.getItems().addAll(years);
    }

    private void sortCountryLists() {
	selectedCountries.sort(comparator);
	countriesData.sort(comparator);
    }

    private void sortIndicatorsLists() {
	selectedIndicators.sort(comparator);
	indicatorsData.sort(comparator);
    }

    @FXML
    public void handleAddCountryButton() {

	if (!countriesData.remove(clickedCountry))
	    return;
	selectedCountries.add(clickedCountry);
	sortCountryLists();
	countriesListView.setItems((ObservableList<String>) countriesData);
	selectedCountriesListView
		.setItems((ObservableList<String>) selectedCountries);
    }

    @FXML
    public void handleDeleteCountryButton() {
	if (!selectedCountries.remove(clickedCountry))
	    return;
	countriesData.add(clickedCountry);
	sortCountryLists();
	countriesListView.setItems((ObservableList<String>) countriesData);
	selectedCountriesListView
		.setItems((ObservableList<String>) selectedCountries);
    }

    @FXML
    public void handleClickOnCountryListView() {
	clickedCountry = (String) countriesListView.getSelectionModel()
		.getSelectedItem();
    }

    @FXML
    public void handleClickOnSelectedCountryListView() {
	clickedCountry = (String) selectedCountriesListView.getSelectionModel()
		.getSelectedItem();
    }

    @FXML
    public void handleAddIndicatorButton() {
	if (!indicatorsData.remove(clickedIndicator))
	    return;
	selectedIndicators.add(clickedIndicator);
	sortIndicatorsLists();
	indicatorsListView.setItems((ObservableList<String>) indicatorsData);
	selectedIndicatorsListView
		.setItems((ObservableList<String>) selectedIndicators);
    }

    @FXML
    public void handleDeleteIndicatorButton() {
	if (!selectedIndicators.remove(clickedIndicator))
	    return;
	indicatorsData.add(clickedIndicator);
	sortIndicatorsLists();
	indicatorsListView.setItems((ObservableList<String>) indicatorsData);
	selectedIndicatorsListView
		.setItems((ObservableList<String>) selectedIndicators);
    }

    @FXML
    public void handleClickOnIndicatorListView() {
	clickedIndicator = (String) indicatorsListView.getSelectionModel()
		.getSelectedItem();
    }

    @FXML
    public void handleClickOnSelectedIndicatorListView() {
	clickedIndicator = (String) selectedIndicatorsListView
		.getSelectionModel().getSelectedItem();
    }

}