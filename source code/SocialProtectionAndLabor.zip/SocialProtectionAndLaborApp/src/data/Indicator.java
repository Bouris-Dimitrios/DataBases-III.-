package data;

public class Indicator {
    private String id;
    private String name;

    public Indicator(String name, String id) {
	this.id = id;
	this.name = name;
    }

    public String getId() {
	return id;
    }

    public String getName() {
	return name;
    }
}