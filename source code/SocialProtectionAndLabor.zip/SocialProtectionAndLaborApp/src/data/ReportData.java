package data;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class ReportData {
    private StringProperty id;
    private  StringProperty path;
    private StringProperty key1;
    private StringProperty key2;
    private StringProperty key3;

    public ReportData(String id, String path, String key1, String key2,
	    String key3) {
	this.id = new SimpleStringProperty(id);
	this.path = new SimpleStringProperty(path);
	this.key1 = new SimpleStringProperty(key1);
	this.key2 = new SimpleStringProperty(key2);
	this.key3 = new SimpleStringProperty(key3);
    }

    public StringProperty getIdProperty() {
	return id;
    }

    public StringProperty getPathProperty() {
    	return path;
    }

    public StringProperty getKey1Property() {
	return key1;
    }

    public StringProperty getKey2Property() {
	return key2;
    }

    public StringProperty getKey3Property() {
	return key3;
    }
}
