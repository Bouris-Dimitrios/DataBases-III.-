package data;

public class Measurement {
   private String country;
   private String indicator;
   private String indicator2;
   private double value;
   private double value2;
   private String year;

    public static Measurement createScatterPlotMeasurement(String country,
	    String indicator, double value, String indicator2, double value2) {
	return new Measurement(country, indicator, value, indicator2, value2);
    }

    public static Measurement createGeneralMeasurement(String country,
	    String indicator, double value, String year) {
	return new Measurement(country, indicator, value, year);
    }

    private Measurement(String country, String indicator, double value,
	    String year) {
	this.country = country;
	this.indicator = indicator;
	this.value = value;
	this.year = year;
	indicator2 = " ";
    }

    private Measurement(String country, String indicator, double value,
	    String indicator2, double value2) {
	this.country = country;
	this.indicator = indicator;
	this.value = value;
	this.indicator2 = indicator2;
	this.value2 = value2;
	this.year = " ";
    }

    public String getCountry() {
	return country;
    }

    public String getIndicator() {
	return indicator;
    }

    public String getIndicator2() {
	return indicator2;
    }

    public String getYear() {
	return year;
    }

    public double getValue() {
	return value;
    }

    public double getValue2() {
	return value2;
    }
}